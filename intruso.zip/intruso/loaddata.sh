echo "Load data..."

mongoimport --uri mongodb+srv://samuel:123@cluster0.dfxrzpa.mongodb.net/banco --collection conta --type json --file conta1.json
mongoimport --uri mongodb+srv://samuel:123@cluster0.dfxrzpa.mongodb.net/banco --collection conta --type json --file conta2.json
mongoimport --uri mongodb+srv://samuel:123@cluster0.dfxrzpa.mongodb.net/banco --collection conta --type json --file conta3.json
