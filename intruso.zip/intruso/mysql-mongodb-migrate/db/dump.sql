use migrate_db;

CREATE TABLE films 
( 
 id INT PRIMARY KEY,  
 name VARCHAR(n) NOT NULL,  
 duration INT NOT NULL,  
 year INT NOT NULL,  
 language VARCHAR(n) NOT NULL,  
 sinopse INT NOT NULL,  
 fk_studio INT,  
); 

CREATE TABLE actors 
( 
 id INT PRIMARY KEY,  
 name VARCHAR(n) NOT NULL,  
); 

CREATE TABLE studios 
( 
 id INT PRIMARY KEY,  
 name INT NOT NULL,  
); 

CREATE TABLE tv_shows 
( 
 id INT PRIMARY KEY,  
 name VARCHAR(n) NOT NULL,  
 year INT NOT NULL,  
 sinopse VARCHAR(n) NOT NULL,  
); 

CREATE TABLE users 
( 
 id INT PRIMARY KEY,  
 name VARCHAR(n) NOT NULL,  
 email VARCHAR(n) NOT NULL,  
 password VARCHAR(n) NOT NULL,  
 dt_time_created DATE NOT NULL,  
 auth_hash VARCHAR(n) NOT NULL,  
 UNIQUE (auth_hash)
); 

CREATE TABLE episodes 
( 
 id INT PRIMARY KEY AUTO_INCREMENT,  
 name VARCHAR(n) NOT NULL,  
 duration INT NOT NULL,  
 season INT NOT NULL,  
 sinopse VARCHAR(n) NOT NULL,  
 fk_tv_show INT,  
); 

CREATE TABLE film_actors 
( 
 id INT PRIMARY KEY,  
 fk_film INT,  
 fk_actors INT,  
); 

CREATE TABLE tv_shows_actors 
( 
 id INT PRIMARY KEY,  
 fk_tv_show INT,  
 fk_actors INT,  
); 

CREATE TABLE films_list 
( 
 id INT PRIMARY KEY,  
 fk_film INT,  
 fk_user INT,  
 evaluation INT,  
); 

CREATE TABLE tv_shows_list 
( 
 id INT PRIMARY KEY,  
 fk_show INT,  
 fk_user INT,  
); 

ALTER TABLE films ADD FOREIGN KEY(fk_studio) REFERENCES studios (fk_studio);
ALTER TABLE episodes ADD FOREIGN KEY(fk_tv_show) REFERENCES tv_shows (fk_tv_show);
ALTER TABLE film_actors ADD FOREIGN KEY(fk_film) REFERENCES films (fk_film);
ALTER TABLE film_actors ADD FOREIGN KEY(fk_actors) REFERENCES actors (fk_actors);
ALTER TABLE tv_shows_actors ADD FOREIGN KEY(fk_tv_show) REFERENCES tv_shows (fk_tv_show);
ALTER TABLE tv_shows_actors ADD FOREIGN KEY(fk_actors) REFERENCES actors (fk_actors);
ALTER TABLE films_list ADD FOREIGN KEY(fk_film) REFERENCES films (fk_film);
ALTER TABLE films_list ADD FOREIGN KEY(fk_user) REFERENCES users (fk_user);
ALTER TABLE tv_shows_list ADD FOREIGN KEY(fk_show) REFERENCES tv_shows (fk_show);
ALTER TABLE tv_shows_list ADD FOREIGN KEY(fk_user) REFERENCES users (fk_user);
